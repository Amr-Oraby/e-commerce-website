(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/@base-ui/react/slider/control/SliderControl.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SliderControl",
    ()=>SliderControl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$addEventListener$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/addEventListener.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/owner.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__getWindow__as__ownerWindow$3e$__ = __turbopack_context__.i("[project]/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs [app-client] (ecmascript) <export getWindow as ownerWindow>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useAnimationFrame$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/useAnimationFrame.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/useStableCallback.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useValueAsRef$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/useValueAsRef.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/shadowDom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$clamp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/clamp.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/createBaseUIEventDetails.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$direction$2d$context$2f$DirectionContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/direction-context/DirectionContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$SliderRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/root/SliderRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/root/stateAttributesMapping.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$getMidpoint$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/utils/getMidpoint.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$roundValueToStep$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/utils/roundValueToStep.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$validateMinimumDistance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/utils/validateMinimumDistance.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$resolveThumbCollision$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/utils/resolveThumbCollision.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const INTENTIONAL_DRAG_COUNT_THRESHOLD = 2;
function getControlOffset(styles, vertical) {
    if (!styles) {
        return {
            start: 0,
            end: 0
        };
    }
    function parseSize(value) {
        const parsed = value != null ? parseFloat(value) : 0;
        return Number.isNaN(parsed) ? 0 : parsed;
    }
    const start = !vertical ? 'InlineStart' : 'Top';
    const end = !vertical ? 'InlineEnd' : 'Bottom';
    return {
        start: parseSize(styles[`border${start}Width`]) + parseSize(styles[`padding${start}`]),
        end: parseSize(styles[`border${end}Width`]) + parseSize(styles[`padding${end}`])
    };
}
function getFingerCoords(event, touchIdRef) {
    // The event is TouchEvent
    if (touchIdRef.current != null && event.changedTouches) {
        const touchEvent = event;
        for(let i = 0; i < touchEvent.changedTouches.length; i += 1){
            const touch = touchEvent.changedTouches[i];
            if (touch.identifier === touchIdRef.current) {
                return {
                    x: touch.clientX,
                    y: touch.clientY
                };
            }
        }
        return null;
    }
    // The event is PointerEvent
    return {
        x: event.clientX,
        y: event.clientY
    };
}
const SliderControl = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function SliderControl(componentProps, forwardedRef) {
    const { render: renderProp, className, style, ...elementProps } = componentProps;
    const { disabled, dragging, inset, lastChangeReasonRef, max, min, minStepsBetweenValues, onValueCommitted, orientation, pressedInputRef, pressedThumbCenterOffsetRef, pressedThumbIndexRef, pressedValuesRef, registerFieldControlRef, renderBeforeHydration, setActive, setDragging, setValue, state, step, thumbCollisionBehavior, thumbRefs, values } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$SliderRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSliderRootContext"])();
    const direction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$direction$2d$context$2f$DirectionContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDirection"])();
    const range = values.length > 1;
    const vertical = orientation === 'vertical';
    const controlRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const stylesRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const setStylesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "SliderControl.SliderControl.useStableCallback[setStylesRef]": (element)=>{
            if (element && stylesRef.current == null) {
                stylesRef.current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__getWindow__as__ownerWindow$3e$__["ownerWindow"])(element).getComputedStyle(element);
            }
        }
    }["SliderControl.SliderControl.useStableCallback[setStylesRef]"]);
    // A number that uniquely identifies the current finger in the touch session.
    const touchIdRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    // The number of touch/pointermove events that have fired.
    const moveCountRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](0);
    // The offset amount to each side of the control for inset sliders.
    // This value should be equal to the radius or half the width/height of the thumb.
    const insetThumbOffsetRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](0);
    const currentInteractionValueRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const latestValuesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useValueAsRef$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValueAsRef"])(values);
    function updatePressedThumb(nextIndex) {
        if (pressedThumbIndexRef.current !== nextIndex) {
            pressedThumbIndexRef.current = nextIndex;
        }
        const thumbElement = thumbRefs.current[nextIndex];
        if (!thumbElement) {
            pressedThumbCenterOffsetRef.current = null;
            pressedInputRef.current = null;
            return;
        }
        pressedInputRef.current = thumbElement.querySelector('input[type="range"]');
    }
    function resetPressedThumb() {
        pressedThumbIndexRef.current = -1;
        pressedThumbCenterOffsetRef.current = null;
        pressedInputRef.current = null;
    }
    function isTargetDisabledThumb(target) {
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"])(target)) {
            return false;
        }
        return thumbRefs.current.some((thumbEl)=>{
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"])(thumbEl) || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["contains"])(thumbEl, target)) {
                return false;
            }
            return thumbEl.querySelector('input[type="range"]')?.disabled === true;
        });
    }
    function getFingerState(fingerCoords) {
        const control = controlRef.current;
        const thumbIndex = pressedThumbIndexRef.current;
        if (!control || !range && (thumbIndex < 0 || thumbIndex >= values.length)) {
            return null;
        }
        const { width, height, bottom, left, right } = control.getBoundingClientRect();
        const controlOffset = getControlOffset(stylesRef.current, vertical);
        const insetThumbOffset = insetThumbOffsetRef.current;
        const controlSize = (vertical ? height : width) - controlOffset.start - controlOffset.end - insetThumbOffset * 2;
        const thumbCenterOffset = pressedThumbCenterOffsetRef.current ?? 0;
        const fingerX = fingerCoords.x - thumbCenterOffset;
        const fingerY = fingerCoords.y - thumbCenterOffset;
        const valueSize = vertical ? bottom - fingerY - controlOffset.end : (direction === 'rtl' ? right - fingerX : fingerX - left) - controlOffset.start;
        // the value at the finger origin scaled down to fit the range [0, 1]
        const valueRescaled = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$clamp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])((valueSize - insetThumbOffset) / controlSize, 0, 1);
        let newValue = (max - min) * valueRescaled + min;
        newValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$roundValueToStep$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["roundValueToStep"])(newValue, step, min);
        newValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$clamp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(newValue, min, max);
        if (!range) {
            return {
                value: newValue,
                thumbIndex,
                didSwap: false
            };
        }
        if (thumbIndex < 0) {
            return null;
        }
        const collisionResult = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$resolveThumbCollision$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveThumbCollision"])({
            behavior: thumbCollisionBehavior,
            values,
            currentValues: latestValuesRef.current ?? values,
            initialValues: pressedValuesRef.current,
            pressedIndex: thumbIndex,
            nextValue: newValue,
            min,
            max,
            step,
            minStepsBetweenValues
        });
        return collisionResult;
    }
    function startPressing(fingerCoords) {
        pressedValuesRef.current = range ? values.slice() : null;
        currentInteractionValueRef.current = null;
        latestValuesRef.current = values;
        const pressedThumbIndex = pressedThumbIndexRef.current;
        let closestThumbIndex = pressedThumbIndex;
        if (pressedThumbIndex > -1 && pressedThumbIndex < values.length) {
            if (values[pressedThumbIndex] === max) {
                let candidateIndex = pressedThumbIndex;
                while(candidateIndex > 0 && values[candidateIndex - 1] === max){
                    candidateIndex -= 1;
                }
                closestThumbIndex = candidateIndex;
            }
        } else {
            // pressed on control
            const axis = !vertical ? 'x' : 'y';
            let minDistance;
            closestThumbIndex = -1;
            for(let i = 0; i < thumbRefs.current.length; i += 1){
                const thumbEl = thumbRefs.current[i];
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"])(thumbEl) && !thumbEl.querySelector('input[type="range"]')?.disabled) {
                    const midpoint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$getMidpoint$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMidpoint"])(thumbEl);
                    const distance = Math.abs(fingerCoords[axis] - midpoint[axis]);
                    if (minDistance === undefined || distance <= minDistance) {
                        closestThumbIndex = i;
                        minDistance = distance;
                    }
                }
            }
        }
        if (closestThumbIndex > -1 && closestThumbIndex !== pressedThumbIndex) {
            updatePressedThumb(closestThumbIndex);
        }
        if (inset) {
            const thumbEl = thumbRefs.current[closestThumbIndex];
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"])(thumbEl)) {
                const thumbRect = thumbEl.getBoundingClientRect();
                const side = !vertical ? 'width' : 'height';
                insetThumbOffsetRef.current = thumbRect[side] / 2;
            }
        }
    }
    function focusThumb(thumbIndex) {
        const input = thumbRefs.current?.[thumbIndex]?.querySelector('input[type="range"]');
        if (!input) {
            return;
        }
        input.focus({
            preventScroll: true,
            // Prevent pointer-driven focus rings in browsers that support this option.
            // Supported in Chrome from 144+.
            focusVisible: false
        });
    }
    function setValueFromPointer(finger, reason, nativeEvent) {
        const applied = setValue(finger.value, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(reason, nativeEvent, undefined, {
            activeThumbIndex: finger.thumbIndex
        }));
        if (applied) {
            currentInteractionValueRef.current = finger.value;
            latestValuesRef.current = Array.isArray(finger.value) ? finger.value : [
                finger.value
            ];
            // Only track the swapped thumb once the change is actually applied so a
            // canceled swap doesn't leak the new index into subsequent moves.
            if (finger.didSwap) {
                updatePressedThumb(finger.thumbIndex);
            }
        }
        return applied;
    }
    const handleTouchMove = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "SliderControl.SliderControl.useStableCallback[handleTouchMove]": (nativeEvent)=>{
            const fingerCoords = getFingerCoords(nativeEvent, touchIdRef);
            if (fingerCoords == null) {
                return;
            }
            moveCountRef.current += 1;
            // Cancel move in case some other element consumed a pointerup event and it was not fired.
            if (nativeEvent.type === 'pointermove' && nativeEvent.buttons === 0) {
                // eslint-disable-next-line @typescript-eslint/no-use-before-define
                handleTouchEnd(nativeEvent);
                return;
            }
            const finger = getFingerState(fingerCoords);
            if (finger == null) {
                return;
            }
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$validateMinimumDistance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateMinimumDistance"])(finger.value, step, minStepsBetweenValues)) {
                if (!dragging && moveCountRef.current > INTENTIONAL_DRAG_COUNT_THRESHOLD) {
                    setDragging(true);
                }
                const applied = setValueFromPointer(finger, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].drag, nativeEvent);
                if (applied && finger.didSwap) {
                    focusThumb(finger.thumbIndex);
                }
            }
        }
    }["SliderControl.SliderControl.useStableCallback[handleTouchMove]"]);
    const handleTouchEnd = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "SliderControl.SliderControl.useStableCallback[handleTouchEnd]": (nativeEvent)=>{
            setActive(-1);
            setDragging(false);
            pressedInputRef.current = null;
            pressedThumbCenterOffsetRef.current = null;
            if (currentInteractionValueRef.current != null) {
                const commitReason = lastChangeReasonRef.current;
                onValueCommitted(currentInteractionValueRef.current, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createGenericEventDetails"])(commitReason, nativeEvent));
            }
            if ('pointerType' in nativeEvent && controlRef.current?.hasPointerCapture(nativeEvent.pointerId)) {
                controlRef.current?.releasePointerCapture(nativeEvent.pointerId);
            }
            pressedThumbIndexRef.current = -1;
            touchIdRef.current = null;
            pressedValuesRef.current = null;
            currentInteractionValueRef.current = null;
            // eslint-disable-next-line @typescript-eslint/no-use-before-define
            stopListening();
        }
    }["SliderControl.SliderControl.useStableCallback[handleTouchEnd]"]);
    const handleTouchStart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "SliderControl.SliderControl.useStableCallback[handleTouchStart]": (nativeEvent)=>{
            if (disabled) {
                return;
            }
            if (isTargetDisabledThumb((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTarget"])(nativeEvent))) {
                resetPressedThumb();
                return;
            }
            const touch = nativeEvent.changedTouches[0];
            if (touch != null) {
                touchIdRef.current = touch.identifier;
            }
            const fingerCoords = getFingerCoords(nativeEvent, touchIdRef);
            if (fingerCoords != null) {
                startPressing(fingerCoords);
                const finger = getFingerState(fingerCoords);
                if (finger == null) {
                    return;
                }
                focusThumb(finger.thumbIndex);
                const applied = setValueFromPointer(finger, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].trackPress, nativeEvent);
                if (applied && finger.didSwap) {
                    focusThumb(finger.thumbIndex);
                }
            }
            moveCountRef.current = 0;
            const doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ownerDocument"])(controlRef.current);
            doc.addEventListener('touchmove', handleTouchMove, {
                passive: true
            });
            doc.addEventListener('touchend', handleTouchEnd, {
                passive: true
            });
        }
    }["SliderControl.SliderControl.useStableCallback[handleTouchStart]"]);
    const stopListening = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "SliderControl.SliderControl.useStableCallback[stopListening]": ()=>{
            const doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ownerDocument"])(controlRef.current);
            doc.removeEventListener('pointermove', handleTouchMove);
            doc.removeEventListener('pointerup', handleTouchEnd);
            doc.removeEventListener('touchmove', handleTouchMove);
            doc.removeEventListener('touchend', handleTouchEnd);
            pressedValuesRef.current = null;
            currentInteractionValueRef.current = null;
        }
    }["SliderControl.SliderControl.useStableCallback[stopListening]"]);
    const focusFrame = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useAnimationFrame$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAnimationFrame"])();
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "SliderControl.SliderControl.useEffect": ()=>{
            const control = controlRef.current;
            if (!control) {
                return ({
                    "SliderControl.SliderControl.useEffect": ()=>stopListening()
                })["SliderControl.SliderControl.useEffect"];
            }
            const unsubscribeTouchStart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$addEventListener$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addEventListener"])(control, 'touchstart', handleTouchStart, {
                passive: true
            });
            return ({
                "SliderControl.SliderControl.useEffect": ()=>{
                    unsubscribeTouchStart();
                    focusFrame.cancel();
                    stopListening();
                }
            })["SliderControl.SliderControl.useEffect"];
        }
    }["SliderControl.SliderControl.useEffect"], [
        stopListening,
        handleTouchStart,
        controlRef,
        focusFrame
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "SliderControl.SliderControl.useEffect": ()=>{
            if (disabled) {
                stopListening();
            }
        }
    }["SliderControl.SliderControl.useEffect"], [
        disabled,
        stopListening
    ]);
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        state,
        ref: [
            forwardedRef,
            registerFieldControlRef,
            controlRef,
            setStylesRef
        ],
        props: [
            {
                ['data-base-ui-slider-control']: renderBeforeHydration ? '' : undefined,
                onPointerDown (event) {
                    const control = controlRef.current;
                    const target = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTarget"])(event.nativeEvent);
                    if (!control || disabled || event.defaultPrevented || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"])(target) || // Only handle left clicks
                    event.button !== 0) {
                        return;
                    }
                    if (isTargetDisabledThumb(target)) {
                        resetPressedThumb();
                        return;
                    }
                    const fingerCoords = getFingerCoords(event, touchIdRef);
                    if (fingerCoords != null) {
                        startPressing(fingerCoords);
                        const finger = getFingerState(fingerCoords);
                        if (finger == null) {
                            return;
                        }
                        const pressedOnFocusedThumb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["contains"])(thumbRefs.current[finger.thumbIndex], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["activeElement"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ownerDocument"])(control)));
                        if (pressedOnFocusedThumb) {
                            event.preventDefault();
                        } else {
                            focusFrame.request({
                                "SliderControl.SliderControl.useRenderElement[element]": ()=>{
                                    focusThumb(finger.thumbIndex);
                                }
                            }["SliderControl.SliderControl.useRenderElement[element]"]);
                        }
                        setDragging(true);
                        const pressedOnAnyThumb = pressedThumbCenterOffsetRef.current != null;
                        if (!pressedOnAnyThumb) {
                            const applied = setValueFromPointer(finger, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].trackPress, event.nativeEvent);
                            if (applied && finger.didSwap) {
                                focusThumb(finger.thumbIndex);
                            }
                        }
                    }
                    if (event.nativeEvent.pointerId) {
                        control.setPointerCapture(event.nativeEvent.pointerId);
                    }
                    moveCountRef.current = 0;
                    const doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ownerDocument"])(controlRef.current);
                    doc.addEventListener('pointermove', handleTouchMove, {
                        passive: true
                    });
                    doc.addEventListener('pointerup', handleTouchEnd, {
                        once: true
                    });
                }
            },
            elementProps
        ],
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sliderStateAttributesMapping"]
    });
    return element;
});
if ("TURBOPACK compile-time truthy", 1) SliderControl.displayName = "SliderControl";
}),
"[project]/node_modules/@base-ui/react/slider/index.parts.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Control",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$control$2f$SliderControl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SliderControl"],
    "Indicator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$indicator$2f$SliderIndicator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SliderIndicator"],
    "Label",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$label$2f$SliderLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SliderLabel"],
    "Root",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$SliderRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SliderRoot"],
    "Thumb",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$thumb$2f$SliderThumb$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SliderThumb"],
    "Track",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$track$2f$SliderTrack$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SliderTrack"],
    "Value",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$value$2f$SliderValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SliderValue"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$index$2e$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/index.parts.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$SliderRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/root/SliderRoot.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$label$2f$SliderLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/label/SliderLabel.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$value$2f$SliderValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/value/SliderValue.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$control$2f$SliderControl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/control/SliderControl.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$track$2f$SliderTrack$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/track/SliderTrack.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$thumb$2f$SliderThumb$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/thumb/SliderThumb.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$indicator$2f$SliderIndicator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/indicator/SliderIndicator.mjs [app-client] (ecmascript)");
}),
"[project]/node_modules/@base-ui/react/slider/index.parts.mjs [app-client] (ecmascript) <export * as Slider>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Slider",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$index$2e$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$index$2e$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/index.parts.mjs [app-client] (ecmascript)");
}),
"[project]/node_modules/@base-ui/react/slider/index.parts.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
;
;
;
;
;
;
}),
"[project]/node_modules/@base-ui/react/slider/indicator/SliderIndicator.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SliderIndicator",
    ()=>SliderIndicator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$valueToPercent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/utils/valueToPercent.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$useIsHydrating$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/utils/useIsHydrating.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$SliderRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/root/SliderRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/root/stateAttributesMapping.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
function getInsetStyles(vertical, range, start, end, renderBeforeHydration, hydrating) {
    const visibility = start === undefined || range && end === undefined ? 'hidden' : undefined;
    const startEdge = vertical ? 'bottom' : 'insetInlineStart';
    const mainSide = vertical ? 'height' : 'width';
    const crossSide = vertical ? 'width' : 'height';
    const styles = {
        visibility: renderBeforeHydration && hydrating ? 'hidden' : visibility,
        position: vertical ? 'absolute' : 'relative',
        [crossSide]: 'inherit'
    };
    styles['--start-position'] = `${start ?? 0}%`;
    if (!range) {
        styles[startEdge] = 0;
        styles[mainSide] = 'var(--start-position)';
        return styles;
    }
    styles['--relative-size'] = `${(end ?? 0) - (start ?? 0)}%`;
    styles[startEdge] = 'var(--start-position)';
    styles[mainSide] = 'var(--relative-size)';
    return styles;
}
function getCenteredStyles(vertical, range, start, end) {
    const startEdge = vertical ? 'bottom' : 'insetInlineStart';
    const mainSide = vertical ? 'height' : 'width';
    const crossSide = vertical ? 'width' : 'height';
    const styles = {
        position: vertical ? 'absolute' : 'relative',
        [crossSide]: 'inherit'
    };
    if (!range) {
        styles[startEdge] = 0;
        styles[mainSide] = `${start}%`;
        return styles;
    }
    const size = end - start;
    styles[startEdge] = `${start}%`;
    styles[mainSide] = `${size}%`;
    return styles;
}
const SliderIndicator = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function SliderIndicator(componentProps, forwardedRef) {
    const { render, className, style: styleProp, ...elementProps } = componentProps;
    const { indicatorPosition, inset, max, min, orientation, renderBeforeHydration, state, values } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$SliderRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSliderRootContext"])();
    const isHydrating = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$useIsHydrating$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsHydrating"])();
    const vertical = orientation === 'vertical';
    const range = values.length > 1;
    const style = inset ? getInsetStyles(vertical, range, indicatorPosition[0], indicatorPosition[1], renderBeforeHydration, isHydrating) : getCenteredStyles(vertical, range, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$valueToPercent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["valueToPercent"])(values[0], min, max), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$valueToPercent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["valueToPercent"])(values[values.length - 1], min, max));
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        state,
        ref: forwardedRef,
        props: [
            {
                ['data-base-ui-slider-indicator']: renderBeforeHydration ? '' : undefined,
                style,
                suppressHydrationWarning: renderBeforeHydration || undefined
            },
            elementProps
        ],
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sliderStateAttributesMapping"]
    });
    return element;
});
if ("TURBOPACK compile-time truthy", 1) SliderIndicator.displayName = "SliderIndicator";
}),
"[project]/node_modules/@base-ui/react/slider/label/SliderLabel.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SliderLabel",
    ()=>SliderLabel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/owner.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$labelable$2d$provider$2f$useLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/labelable-provider/useLabel.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$SliderRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/root/SliderRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/root/stateAttributesMapping.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
const SliderLabel = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function SliderLabel(componentProps, forwardedRef) {
    const { render, className, style, ...elementProps } = componentProps;
    // Keep label id derived from the root and ignore runtime `id` overrides from untyped consumers.
    const elementPropsWithoutId = elementProps;
    delete elementPropsWithoutId.id;
    const { state, setLabelId, controlRef, rootLabelId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$SliderRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSliderRootContext"])();
    function focusControl(event, controlId) {
        if (controlId) {
            const controlElement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ownerDocument"])(event.currentTarget).getElementById(controlId);
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(controlElement)) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$labelable$2d$provider$2f$useLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["focusElementWithVisible"])(controlElement);
                return;
            }
        }
        const fallbackInputs = controlRef.current?.querySelectorAll('input[type="range"]');
        const fallbackInput = fallbackInputs?.length === 1 ? fallbackInputs[0] : null;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(fallbackInput)) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$labelable$2d$provider$2f$useLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["focusElementWithVisible"])(fallbackInput);
        }
    }
    const labelProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$labelable$2d$provider$2f$useLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLabel"])({
        id: rootLabelId,
        setLabelId,
        focusControl
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        ref: forwardedRef,
        state,
        props: [
            labelProps,
            elementProps
        ],
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sliderStateAttributesMapping"]
    });
});
if ("TURBOPACK compile-time truthy", 1) SliderLabel.displayName = "SliderLabel";
}),
"[project]/node_modules/@base-ui/react/slider/root/SliderRoot.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SliderRoot",
    ()=>SliderRoot
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/owner.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useControlled$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/useControlled.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/useStableCallback.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useValueAsRef$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/useValueAsRef.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$warn$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/warn.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/createBaseUIEventDetails.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useValueChanged$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/useValueChanged.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/useBaseUiId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$clamp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/clamp.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$areArraysEqual$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/areArraysEqual.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/shadowDom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$CompositeList$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/composite/list/CompositeList.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$field$2d$root$2d$context$2f$FieldRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/field-root-context/FieldRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$field$2d$register$2d$control$2f$useRegisterFieldControl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/field-register-control/useRegisterFieldControl.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$form$2d$context$2f$FormContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/form-context/FormContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$labelable$2d$provider$2f$LabelableContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/labelable-provider/LabelableContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$resolveAriaLabelledBy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/utils/resolveAriaLabelledBy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$asc$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/utils/asc.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$getSliderValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/utils/getSliderValue.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$validateMinimumDistance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/utils/validateMinimumDistance.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/root/stateAttributesMapping.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$SliderRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/root/SliderRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function getSliderChangeEventReason(event) {
    return 'key' in event ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].keyboard : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].inputChange;
}
function areValuesEqual(newValue, oldValue) {
    if (typeof newValue === 'number' && typeof oldValue === 'number') {
        return newValue === oldValue;
    }
    if (Array.isArray(newValue) && Array.isArray(oldValue)) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$areArraysEqual$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["areArraysEqual"])(newValue, oldValue);
    }
    return false;
}
const SliderRoot = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function SliderRoot(componentProps, forwardedRef) {
    const { 'aria-labelledby': ariaLabelledByProp, className, defaultValue, disabled: disabledProp = false, id: idProp, format, largeStep = 10, locale, render, max = 100, min = 0, minStepsBetweenValues = 0, form, name: nameProp, onValueChange: onValueChangeProp, onValueCommitted: onValueCommittedProp, orientation = 'horizontal', step = 1, thumbCollisionBehavior = 'push', thumbAlignment = 'center', value: valueProp, style, ...elementProps } = componentProps;
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])(idProp);
    const defaultLabelId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$resolveAriaLabelledBy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultLabelId"])(id);
    const onValueChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])(onValueChangeProp);
    const onValueCommitted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])(onValueCommittedProp);
    const { clearErrors } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$form$2d$context$2f$FormContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormContext"])();
    const { state: fieldState, disabled: fieldDisabled, name: fieldName, setTouched, setDirty, validityData, validation } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$field$2d$root$2d$context$2f$FieldRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFieldRootContext"])();
    const { labelId: fieldLabelId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$labelable$2d$provider$2f$LabelableContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLabelableContext"])();
    const [labelId, setLabelId] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]();
    const ariaLabelledby = ariaLabelledByProp ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$resolveAriaLabelledBy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveAriaLabelledBy"])(fieldLabelId, labelId);
    const disabled = fieldDisabled || disabledProp;
    const name = fieldName ?? nameProp;
    // The internal value is potentially unsorted, e.g. to support frozen arrays
    // https://github.com/mui/material-ui/pull/28472
    const [valueUnwrapped, setValueUnwrapped] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useControlled$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControlled"])({
        controlled: valueProp,
        default: defaultValue ?? min,
        name: 'Slider'
    });
    const sliderRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const controlRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const thumbRefs = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]([]);
    // The input element nested in the pressed thumb.
    const pressedInputRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    // The px distance between the pointer and the center of a pressed thumb.
    const pressedThumbCenterOffsetRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    // The index of the pressed thumb, or the closest thumb if the `Control` was pressed.
    // This is updated on pointerdown, which is sooner than the `active/activeIndex`
    // state which is updated later when the nested `input` receives focus.
    const pressedThumbIndexRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](-1);
    // The values when the current drag interaction started.
    const pressedValuesRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const lastChangeReasonRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]('none');
    const formatOptionsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useValueAsRef$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValueAsRef"])(format);
    // We can't use the :active browser pseudo-classes.
    // - The active state isn't triggered when clicking on the rail.
    // - The active state isn't transferred when inversing a range slider.
    const [active, setActiveState] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](-1);
    const [lastUsedThumbIndex, setLastUsedThumbIndex] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](-1);
    const [dragging, setDragging] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const [thumbMap, setThumbMap] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({
        "SliderRoot.SliderRoot.useState": ()=>new Map()
    }["SliderRoot.SliderRoot.useState"]);
    const [indicatorPosition, setIndicatorPosition] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([
        undefined,
        undefined
    ]);
    const setActive = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "SliderRoot.SliderRoot.useStableCallback[setActive]": (value)=>{
            setActiveState(value);
            if (value !== -1) {
                setLastUsedThumbIndex(value);
            }
        }
    }["SliderRoot.SliderRoot.useStableCallback[setActive]"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$field$2d$register$2d$control$2f$useRegisterFieldControl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRegisterFieldControl"])(validation.inputRef, id, valueUnwrapped, undefined, !disabled, nameProp);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useValueChanged$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValueChanged"])(valueUnwrapped, {
        "SliderRoot.SliderRoot.useValueChanged": ()=>{
            clearErrors(name);
            validation.change(valueUnwrapped);
            const initialValue = validityData.initialValue;
            let isDirty;
            if (Array.isArray(valueUnwrapped) && Array.isArray(initialValue)) {
                isDirty = !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$areArraysEqual$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["areArraysEqual"])(valueUnwrapped, initialValue);
            } else {
                isDirty = valueUnwrapped !== initialValue;
            }
            setDirty(isDirty);
        }
    }["SliderRoot.SliderRoot.useValueChanged"]);
    const registerFieldControlRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "SliderRoot.SliderRoot.useStableCallback[registerFieldControlRef]": (element)=>{
            if (element) {
                controlRef.current = element;
            }
        }
    }["SliderRoot.SliderRoot.useStableCallback[registerFieldControlRef]"]);
    const range = Array.isArray(valueUnwrapped);
    const values = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "SliderRoot.SliderRoot.useMemo[values]": ()=>{
            if (!range) {
                return [
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$clamp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(valueUnwrapped, min, max)
                ];
            }
            return valueUnwrapped.slice().sort(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$asc$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["asc"]);
        }
    }["SliderRoot.SliderRoot.useMemo[values]"], [
        max,
        min,
        range,
        valueUnwrapped
    ]);
    const setValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "SliderRoot.SliderRoot.useStableCallback[setValue]": (newValue, details)=>{
            if (Number.isNaN(newValue) || areValuesEqual(newValue, valueUnwrapped)) {
                return false;
            }
            const changeDetails = details ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].none, undefined, undefined, {
                activeThumbIndex: -1
            });
            // Redefine target to allow name and value to be read.
            // This allows seamless integration with the most popular form libraries.
            // https://github.com/mui/material-ui/issues/13485#issuecomment-676048492
            // Clone the event to not override `target` of the original event.
            const nativeEvent = changeDetails.event;
            const EventConstructor = nativeEvent.constructor ?? Event;
            const clonedEvent = new EventConstructor(nativeEvent.type, nativeEvent);
            Object.defineProperty(clonedEvent, 'target', {
                writable: true,
                value: {
                    value: newValue,
                    name
                }
            });
            changeDetails.event = clonedEvent;
            onValueChange(newValue, changeDetails);
            if (changeDetails.isCanceled) {
                return false;
            }
            lastChangeReasonRef.current = changeDetails.reason;
            setValueUnwrapped(newValue);
            return true;
        }
    }["SliderRoot.SliderRoot.useStableCallback[setValue]"]);
    const handleInputChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "SliderRoot.SliderRoot.useStableCallback[handleInputChange]": (valueInput, index, event)=>{
            const newValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$getSliderValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSliderValue"])(valueInput, index, min, max, range, values);
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$validateMinimumDistance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateMinimumDistance"])(newValue, step, minStepsBetweenValues)) {
                const reason = getSliderChangeEventReason(event);
                const applied = setValue(newValue, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(reason, event.nativeEvent, undefined, {
                    activeThumbIndex: index
                }));
                setTouched(true);
                if (applied) {
                    onValueCommitted(newValue, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createGenericEventDetails"])(reason, event.nativeEvent));
                }
            }
        }
    }["SliderRoot.SliderRoot.useStableCallback[handleInputChange]"]);
    if ("TURBOPACK compile-time truthy", 1) {
        if (min >= max) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$warn$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["warn"])('Slider `max` must be greater than `min`.');
        }
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "SliderRoot.SliderRoot.useIsoLayoutEffect": ()=>{
            const activeEl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["activeElement"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ownerDocument"])(sliderRef.current));
            if (disabled && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["contains"])(sliderRef.current, activeEl)) {
                // This is necessary because Firefox and Safari will keep focus
                // on a disabled element:
                // https://codesandbox.io/p/sandbox/mui-pr-22247-forked-h151h?file=/src/App.js
                activeEl.blur();
            }
        }
    }["SliderRoot.SliderRoot.useIsoLayoutEffect"], [
        disabled
    ]);
    if (disabled && active !== -1) {
        setActive(-1);
    }
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "SliderRoot.SliderRoot.useMemo[state]": ()=>({
                ...fieldState,
                activeThumbIndex: active,
                disabled,
                dragging,
                orientation,
                max,
                min,
                minStepsBetweenValues,
                step,
                values
            })
    }["SliderRoot.SliderRoot.useMemo[state]"], [
        fieldState,
        active,
        disabled,
        dragging,
        max,
        min,
        minStepsBetweenValues,
        orientation,
        step,
        values
    ]);
    const contextValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "SliderRoot.SliderRoot.useMemo[contextValue]": ()=>({
                active,
                controlRef,
                disabled,
                dragging,
                validation,
                formatOptionsRef,
                handleInputChange,
                indicatorPosition,
                inset: thumbAlignment !== 'center',
                labelId: ariaLabelledby,
                rootLabelId: defaultLabelId,
                largeStep,
                lastUsedThumbIndex,
                lastChangeReasonRef,
                form,
                locale,
                max,
                min,
                minStepsBetweenValues,
                name,
                onValueCommitted,
                orientation,
                pressedInputRef,
                pressedThumbCenterOffsetRef,
                pressedThumbIndexRef,
                pressedValuesRef,
                registerFieldControlRef,
                renderBeforeHydration: thumbAlignment === 'edge',
                setActive,
                setDragging,
                setIndicatorPosition,
                setLabelId,
                setValue,
                state,
                step,
                thumbCollisionBehavior,
                thumbMap,
                thumbRefs,
                values
            })
    }["SliderRoot.SliderRoot.useMemo[contextValue]"], [
        active,
        controlRef,
        ariaLabelledby,
        defaultLabelId,
        disabled,
        dragging,
        validation,
        formatOptionsRef,
        handleInputChange,
        indicatorPosition,
        largeStep,
        lastUsedThumbIndex,
        lastChangeReasonRef,
        form,
        locale,
        max,
        min,
        minStepsBetweenValues,
        name,
        onValueCommitted,
        orientation,
        pressedInputRef,
        pressedThumbCenterOffsetRef,
        pressedThumbIndexRef,
        pressedValuesRef,
        registerFieldControlRef,
        setActive,
        setDragging,
        setIndicatorPosition,
        setLabelId,
        setValue,
        state,
        step,
        thumbCollisionBehavior,
        thumbAlignment,
        thumbMap,
        thumbRefs,
        values
    ]);
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        state,
        ref: [
            forwardedRef,
            sliderRef
        ],
        props: [
            {
                'aria-labelledby': ariaLabelledby,
                id,
                role: 'group'
            },
            elementProps,
            {
                "SliderRoot.SliderRoot.useRenderElement[element]": (props)=>validation.getValidationProps(disabled, props)
            }["SliderRoot.SliderRoot.useRenderElement[element]"]
        ],
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sliderStateAttributesMapping"]
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$SliderRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SliderRootContext"].Provider, {
        value: contextValue,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$CompositeList$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CompositeList"], {
            elementsRef: thumbRefs,
            onMapChange: setThumbMap,
            children: element
        })
    });
});
if ("TURBOPACK compile-time truthy", 1) SliderRoot.displayName = "SliderRoot";
}),
"[project]/node_modules/@base-ui/react/slider/root/SliderRootContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SliderRootContext",
    ()=>SliderRootContext,
    "useSliderRootContext",
    ()=>useSliderRootContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
const SliderRootContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) SliderRootContext.displayName = "SliderRootContext";
function useSliderRootContext() {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](SliderRootContext);
    if (context === undefined) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: SliderRootContext is missing. Slider parts must be placed within <Slider.Root>.' : "TURBOPACK unreachable");
    }
    return context;
}
}),
"[project]/node_modules/@base-ui/react/slider/root/stateAttributesMapping.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "sliderStateAttributesMapping",
    ()=>sliderStateAttributesMapping
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$field$2d$constants$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/field-constants/constants.mjs [app-client] (ecmascript)");
;
const sliderStateAttributesMapping = {
    activeThumbIndex: ()=>null,
    max: ()=>null,
    min: ()=>null,
    minStepsBetweenValues: ()=>null,
    step: ()=>null,
    values: ()=>null,
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$field$2d$constants$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fieldValidityMapping"]
};
}),
"[project]/node_modules/@base-ui/react/slider/thumb/SliderThumb.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SliderThumb",
    ()=>SliderThumb
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/useStableCallback.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useMergedRefs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/useMergedRefs.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$visuallyHidden$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/visuallyHidden.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__getWindow__as__ownerWindow$3e$__ = __turbopack_context__.i("[project]/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs [app-client] (ecmascript) <export getWindow as ownerWindow>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$clamp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/clamp.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$formatNumber$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/utils/formatNumber.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/merge-props/mergeProps.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/useBaseUiId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$useIsHydrating$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/utils/useIsHydrating.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$valueToPercent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/utils/valueToPercent.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/composite/composite.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$useCompositeListItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/composite/list/useCompositeListItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$direction$2d$context$2f$DirectionContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/direction-context/DirectionContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$csp$2d$context$2f$CSPContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/csp-context/CSPContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$field$2d$root$2d$context$2f$FieldRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/field-root-context/FieldRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$element$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/floating-ui-react/utils/element.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$labelable$2d$provider$2f$useLabelableId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/labelable-provider/useLabelableId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$getMidpoint$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/utils/getMidpoint.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$getSliderValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/utils/getSliderValue.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$roundValueToStep$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/utils/roundValueToStep.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$SliderRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/root/SliderRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/root/stateAttributesMapping.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$thumb$2f$SliderThumbDataAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/thumb/SliderThumbDataAttributes.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$thumb$2f$prehydrationScript$2e$min$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/thumb/prehydrationScript.min.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const ALL_KEYS = new Set([
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["COMPOSITE_KEYS"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PAGE_UP"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PAGE_DOWN"]
]);
function getDefaultAriaValueText(values, index, format, locale) {
    if (index < 0) {
        return undefined;
    }
    if (values.length === 2) {
        if (index === 0) {
            return `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$formatNumber$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatNumber"])(values[index], locale, format)} start range`;
        }
        return `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$formatNumber$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatNumber"])(values[index], locale, format)} end range`;
    }
    return format ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$formatNumber$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatNumber"])(values[index], locale, format) : undefined;
}
function getNewValue(thumbValue, increment, direction, min, max) {
    const value = direction === 1 ? thumbValue + increment : thumbValue - increment;
    const roundedValue = Number(value.toFixed(Math.max((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$roundValueToStep$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDecimalPrecision"])(thumbValue), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$roundValueToStep$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDecimalPrecision"])(increment), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$roundValueToStep$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDecimalPrecision"])(min))));
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$clamp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(roundedValue, min, max);
}
const SliderThumb = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function SliderThumb(componentProps, forwardedRef) {
    const { render, children: childrenProp, className, 'aria-describedby': ariaDescribedByProp, 'aria-label': ariaLabelProp, 'aria-labelledby': ariaLabelledByProp, 'aria-valuetext': ariaValueTextProp, disabled: disabledProp = false, getAriaLabel: getAriaLabelProp, getAriaValueText: getAriaValueTextProp, id: idProp, index: indexProp, inputRef: inputRefProp, onBlur: onBlurProp, onFocus: onFocusProp, onKeyDown: onKeyDownProp, tabIndex: tabIndexProp, style, ...elementProps } = componentProps;
    const { nonce } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$csp$2d$context$2f$CSPContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCSPContext"])();
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])(idProp);
    const { active: activeIndex, lastUsedThumbIndex, controlRef, disabled: contextDisabled, validation, formatOptionsRef, handleInputChange, inset, labelId, largeStep, locale, max, min, minStepsBetweenValues, form, name, orientation, pressedInputRef, pressedThumbCenterOffsetRef, pressedThumbIndexRef, renderBeforeHydration, setActive, setIndicatorPosition, state, step, values: sliderValues } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$SliderRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSliderRootContext"])();
    const direction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$direction$2d$context$2f$DirectionContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDirection"])();
    const disabled = disabledProp || contextDisabled;
    const range = sliderValues.length > 1;
    const vertical = orientation === 'vertical';
    const rtl = direction === 'rtl';
    const { setTouched, setFocused, validationMode } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$field$2d$root$2d$context$2f$FieldRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFieldRootContext"])();
    const thumbRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const inputRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const restoringFocusVisibleRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    const defaultInputId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])();
    const labelableId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$labelable$2d$provider$2f$useLabelableId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLabelableId"])();
    const inputId = range ? defaultInputId : labelableId;
    const thumbMetadata = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "SliderThumb.SliderThumb.useMemo[thumbMetadata]": ()=>({
                inputId
            })
    }["SliderThumb.SliderThumb.useMemo[thumbMetadata]"], [
        inputId
    ]);
    const { ref: listItemRef, index: compositeIndex } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$useCompositeListItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompositeListItem"])({
        metadata: thumbMetadata
    });
    const index = !range ? 0 : indexProp ?? compositeIndex;
    const last = index === sliderValues.length - 1;
    const thumbValue = sliderValues[index];
    const thumbValuePercent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$valueToPercent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["valueToPercent"])(thumbValue, min, max);
    const [positionPercent, setPositionPercent] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]();
    const isHydrating = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$useIsHydrating$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsHydrating"])();
    const safeLastUsedThumbIndex = lastUsedThumbIndex >= 0 && lastUsedThumbIndex < sliderValues.length ? lastUsedThumbIndex : -1;
    const getInsetPosition = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "SliderThumb.SliderThumb.useStableCallback[getInsetPosition]": ()=>{
            const control = controlRef.current;
            const thumb = thumbRef.current;
            if (!control || !thumb) {
                return;
            }
            const thumbRect = thumb.getBoundingClientRect();
            const controlRect = control.getBoundingClientRect();
            const side = vertical ? 'height' : 'width';
            // the total travel distance adjusted to account for the thumb size
            const controlSize = controlRect[side] - thumbRect[side];
            // px distance from the starting edge (inline-start or bottom) to the thumb center
            const thumbOffsetFromControlEdge = thumbRect[side] / 2 + controlSize * thumbValuePercent / 100;
            const nextPositionPercent = thumbOffsetFromControlEdge / controlRect[side] * 100;
            const nextInsetPosition = Number.isFinite(nextPositionPercent) ? nextPositionPercent : undefined;
            setPositionPercent(nextInsetPosition);
            if (index === 0) {
                setIndicatorPosition({
                    "SliderThumb.SliderThumb.useStableCallback[getInsetPosition]": (prevPosition)=>[
                            nextInsetPosition,
                            prevPosition[1]
                        ]
                }["SliderThumb.SliderThumb.useStableCallback[getInsetPosition]"]);
            } else if (last) {
                setIndicatorPosition({
                    "SliderThumb.SliderThumb.useStableCallback[getInsetPosition]": (prevPosition)=>[
                            prevPosition[0],
                            nextInsetPosition
                        ]
                }["SliderThumb.SliderThumb.useStableCallback[getInsetPosition]"]);
            }
        }
    }["SliderThumb.SliderThumb.useStableCallback[getInsetPosition]"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "SliderThumb.SliderThumb.useIsoLayoutEffect": ()=>{
            if (inset) {
                queueMicrotask(getInsetPosition);
            }
        }
    }["SliderThumb.SliderThumb.useIsoLayoutEffect"], [
        getInsetPosition,
        inset
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "SliderThumb.SliderThumb.useIsoLayoutEffect": ()=>{
            if (inset) {
                getInsetPosition();
            }
        }
    }["SliderThumb.SliderThumb.useIsoLayoutEffect"], [
        getInsetPosition,
        inset,
        thumbValuePercent
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "SliderThumb.SliderThumb.useIsoLayoutEffect": ()=>{
            if (!inset) {
                return undefined;
            }
            const control = controlRef.current;
            const thumb = thumbRef.current;
            if (!control || !thumb) {
                return undefined;
            }
            const ResizeObserverCtor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__getWindow__as__ownerWindow$3e$__["ownerWindow"])(control).ResizeObserver;
            if (typeof ResizeObserverCtor !== 'function') {
                return undefined;
            }
            const resizeObserver = new ResizeObserverCtor(getInsetPosition);
            resizeObserver.observe(control);
            resizeObserver.observe(thumb);
            return ({
                "SliderThumb.SliderThumb.useIsoLayoutEffect": ()=>{
                    resizeObserver.disconnect();
                }
            })["SliderThumb.SliderThumb.useIsoLayoutEffect"];
        }
    }["SliderThumb.SliderThumb.useIsoLayoutEffect"], [
        controlRef,
        getInsetPosition,
        inset
    ]);
    const startEdge = vertical ? 'bottom' : 'insetInlineStart';
    const crossOffsetProperty = vertical ? 'left' : 'top';
    let zIndex;
    if (range) {
        if (activeIndex === index) {
            zIndex = 2;
        } else if (safeLastUsedThumbIndex === index) {
            zIndex = 1;
        }
    } else if (activeIndex === index) {
        zIndex = 1;
    }
    let thumbStyle;
    if (inset) {
        thumbStyle = {
            ['--position']: `${positionPercent ?? 0}%`,
            visibility: renderBeforeHydration && isHydrating || positionPercent === undefined ? 'hidden' : undefined,
            position: 'absolute',
            [startEdge]: 'var(--position)',
            [crossOffsetProperty]: '50%',
            translate: `${(vertical || !rtl ? -1 : 1) * 50}% ${(vertical ? 1 : -1) * 50}%`,
            zIndex
        };
    } else {
        thumbStyle = !Number.isFinite(thumbValuePercent) ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$visuallyHidden$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["visuallyHidden"] : {
            position: 'absolute',
            [startEdge]: `${thumbValuePercent}%`,
            [crossOffsetProperty]: '50%',
            translate: `${(vertical || !rtl ? -1 : 1) * 50}% ${(vertical ? 1 : -1) * 50}%`,
            zIndex
        };
    }
    let cssWritingMode;
    if (orientation === 'vertical') {
        cssWritingMode = rtl ? 'vertical-rl' : 'vertical-lr';
    }
    const ariaLabel = typeof getAriaLabelProp === 'function' ? getAriaLabelProp(index) : ariaLabelProp;
    const inputProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])({
        'aria-label': ariaLabel,
        'aria-labelledby': ariaLabelledByProp ?? (ariaLabel == null ? labelId : undefined),
        'aria-describedby': ariaDescribedByProp,
        'aria-orientation': orientation,
        'aria-valuenow': thumbValue,
        'aria-valuetext': typeof getAriaValueTextProp === 'function' ? getAriaValueTextProp((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$formatNumber$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatNumber"])(thumbValue, locale, formatOptionsRef.current ?? undefined), thumbValue, index) : ariaValueTextProp ?? getDefaultAriaValueText(sliderValues, index, formatOptionsRef.current ?? undefined, locale),
        disabled,
        form,
        id: inputId,
        max,
        min,
        name,
        onChange (event) {
            handleInputChange(event.currentTarget.valueAsNumber, index, event);
        },
        onFocus (event) {
            const isRestoringFocusVisible = restoringFocusVisibleRef.current;
            restoringFocusVisibleRef.current = false;
            setActive(index);
            setFocused(true);
            if (isRestoringFocusVisible) {
                event.stopPropagation();
            }
        },
        onBlur (event) {
            if (restoringFocusVisibleRef.current) {
                event.stopPropagation();
                return;
            }
            if (!thumbRef.current) {
                return;
            }
            setActive(-1);
            setTouched(true);
            setFocused(false);
            if (validationMode === 'onBlur') {
                validation.commit((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$getSliderValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSliderValue"])(thumbValue, index, min, max, range, sliderValues));
            }
        },
        onKeyDown (event) {
            if (event.defaultPrevented) {
                return;
            }
            if (!ALL_KEYS.has(event.key)) {
                return;
            }
            if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["COMPOSITE_KEYS"].has(event.key)) {
                event.stopPropagation();
            }
            let newValue = null;
            const roundedValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$roundValueToStep$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["roundValueToStep"])(thumbValue, step, min);
            switch(event.key){
                case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ARROW_UP"]:
                    newValue = getNewValue(roundedValue, event.shiftKey ? largeStep : step, 1, min, max);
                    break;
                case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ARROW_RIGHT"]:
                    newValue = getNewValue(roundedValue, event.shiftKey ? largeStep : step, rtl ? -1 : 1, min, max);
                    break;
                case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ARROW_DOWN"]:
                    newValue = getNewValue(roundedValue, event.shiftKey ? largeStep : step, -1, min, max);
                    break;
                case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ARROW_LEFT"]:
                    newValue = getNewValue(roundedValue, event.shiftKey ? largeStep : step, rtl ? 1 : -1, min, max);
                    break;
                case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PAGE_UP"]:
                    newValue = getNewValue(roundedValue, largeStep, 1, min, max);
                    break;
                case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PAGE_DOWN"]:
                    newValue = getNewValue(roundedValue, largeStep, -1, min, max);
                    break;
                case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["END"]:
                    newValue = max;
                    if (range) {
                        newValue = Number.isFinite(sliderValues[index + 1]) ? sliderValues[index + 1] - step * minStepsBetweenValues : max;
                    }
                    break;
                case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HOME"]:
                    newValue = min;
                    if (range) {
                        newValue = Number.isFinite(sliderValues[index - 1]) ? sliderValues[index - 1] + step * minStepsBetweenValues : min;
                    }
                    break;
                default:
                    break;
            }
            if (newValue !== null) {
                const input = event.currentTarget;
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$element$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["matchesFocusVisible"])(input)) {
                    restoringFocusVisibleRef.current = true;
                    input.blur();
                    input.focus({
                        preventScroll: true,
                        // Show `:focus-visible` after keyboard interaction, even if the
                        // thumb was previously focused by a pointer.
                        focusVisible: true
                    });
                }
                handleInputChange(newValue, index, event);
                event.preventDefault();
            }
        },
        step,
        style: {
            ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$visuallyHidden$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["visuallyHidden"],
            // So that VoiceOver's focus indicator matches the thumb's dimensions
            width: '100%',
            height: '100%',
            writingMode: cssWritingMode
        },
        tabIndex: tabIndexProp ?? undefined,
        type: 'range',
        value: thumbValue ?? ''
    }, (props)=>validation.getValidationProps(disabled, props), {
        onKeyDown: onKeyDownProp
    });
    const mergedInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useMergedRefs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergedRefs"])(inputRef, validation.inputRef, inputRefProp);
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        state,
        ref: [
            forwardedRef,
            listItemRef,
            thumbRef
        ],
        props: [
            {
                [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$thumb$2f$SliderThumbDataAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SliderThumbDataAttributes"].index]: index,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        childrenProp,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("input", {
                            ref: mergedInputRef,
                            ...inputProps,
                            suppressHydrationWarning: true
                        }),
                        inset && isHydrating && renderBeforeHydration && // this must be rendered with the last thumb to ensure all
                        // preceding thumbs are already rendered in the DOM
                        last && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("script", {
                            nonce: nonce,
                            dangerouslySetInnerHTML: {
                                __html: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$thumb$2f$prehydrationScript$2e$min$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["script"]
                            },
                            suppressHydrationWarning: true
                        })
                    ]
                }),
                id,
                onBlur: onBlurProp,
                onFocus: onFocusProp,
                onPointerDown (event) {
                    // Keep disabled thumbs from writing transient pointer state.
                    if (disabled) {
                        return;
                    }
                    pressedThumbIndexRef.current = index;
                    if (thumbRef.current != null) {
                        const axis = orientation === 'horizontal' ? 'x' : 'y';
                        const midpoint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$getMidpoint$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMidpoint"])(thumbRef.current);
                        const offset = (orientation === 'horizontal' ? event.clientX : event.clientY) - midpoint[axis];
                        pressedThumbCenterOffsetRef.current = offset;
                    }
                    if (inputRef.current != null && pressedInputRef.current !== inputRef.current) {
                        pressedInputRef.current = inputRef.current;
                    }
                },
                style: thumbStyle,
                suppressHydrationWarning: renderBeforeHydration || undefined
            },
            elementProps
        ],
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sliderStateAttributesMapping"]
    });
    return element;
});
if ("TURBOPACK compile-time truthy", 1) SliderThumb.displayName = "SliderThumb";
}),
"[project]/node_modules/@base-ui/react/slider/thumb/SliderThumbDataAttributes.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SliderThumbDataAttributes",
    ()=>SliderThumbDataAttributes
]);
let SliderThumbDataAttributes = /*#__PURE__*/ function(SliderThumbDataAttributes) {
    /**
   * Indicates the index of the thumb in range sliders.
   */ SliderThumbDataAttributes["index"] = "data-index";
    /**
   * Present while the user is dragging.
   */ SliderThumbDataAttributes["dragging"] = "data-dragging";
    /**
   * Indicates the orientation of the slider.
   * @type {'horizontal' | 'vertical'}
   */ SliderThumbDataAttributes["orientation"] = "data-orientation";
    /**
   * Present when the slider is disabled.
   */ SliderThumbDataAttributes["disabled"] = "data-disabled";
    /**
   * Present when the slider is in a valid state (when wrapped in Field.Root).
   */ SliderThumbDataAttributes["valid"] = "data-valid";
    /**
   * Present when the slider is in an invalid state (when wrapped in Field.Root).
   */ SliderThumbDataAttributes["invalid"] = "data-invalid";
    /**
   * Present when the slider has been touched (when wrapped in Field.Root).
   */ SliderThumbDataAttributes["touched"] = "data-touched";
    /**
   * Present when the slider's value has changed (when wrapped in Field.Root).
   */ SliderThumbDataAttributes["dirty"] = "data-dirty";
    /**
   * Present when the slider is focused (when wrapped in Field.Root).
   */ SliderThumbDataAttributes["focused"] = "data-focused";
    return SliderThumbDataAttributes;
}({});
}),
"[project]/node_modules/@base-ui/react/slider/thumb/prehydrationScript.min.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// This file is autogenerated. Do not edit it directly.
// To update it, modify the corresponding source file and run `pnpm inline-scripts`.
// prettier-ignore
__turbopack_context__.s([
    "script",
    ()=>script
]);
const script = '!function(){const t=document.currentScript?.parentElement;if(!t)return;const e=t.closest("[data-base-ui-slider-control]");if(!e)return;const r=e.querySelector("[data-base-ui-slider-indicator]"),i=e.getBoundingClientRect(),n="vertical"===e.getAttribute("data-orientation")?"height":"width",o=e.querySelectorAll(\'input[type="range"]\'),l=o.length>1,s=o.length-1;let a=null,u=null;for(let t=0;t<o.length;t+=1){const e=o[t],y=parseFloat(e.getAttribute("value")??"");if(Number.isNaN(y))return;const c=e.parentElement;if(!c)return;const p=parseFloat(e.getAttribute("max")??"100"),g=parseFloat(e.getAttribute("min")??"0"),b=c?.getBoundingClientRect(),d=i[n]-b[n],m=100*(y-g)/(p-g),v=(b[n]/2+d*m/100)/i[n]*100;c.style.setProperty("--position",`${v}%`),Number.isFinite(v)&&(c.style.removeProperty("visibility"),r&&(0===t?(a=v,r.style.setProperty("--start-position",`${v}%`),l||r.style.removeProperty("visibility")):t===s&&(u=v-(a??0),r.style.setProperty("--end-position",`${v}%`),r.style.setProperty("--relative-size",`${u}%`),r.style.removeProperty("visibility"))))}}();';
}),
"[project]/node_modules/@base-ui/react/slider/track/SliderTrack.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SliderTrack",
    ()=>SliderTrack
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$SliderRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/root/SliderRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/root/stateAttributesMapping.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
const SliderTrack = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function SliderTrack(componentProps, forwardedRef) {
    const { render, className, style, ...elementProps } = componentProps;
    const { state } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$SliderRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSliderRootContext"])();
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        state,
        ref: forwardedRef,
        props: [
            {
                style: {
                    position: 'relative'
                }
            },
            elementProps
        ],
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sliderStateAttributesMapping"]
    });
    return element;
});
if ("TURBOPACK compile-time truthy", 1) SliderTrack.displayName = "SliderTrack";
}),
"[project]/node_modules/@base-ui/react/slider/utils/asc.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "asc",
    ()=>asc
]);
function asc(a, b) {
    return a - b;
}
}),
"[project]/node_modules/@base-ui/react/slider/utils/getMidpoint.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getMidpoint",
    ()=>getMidpoint
]);
function getMidpoint(element) {
    const rect = element.getBoundingClientRect();
    return {
        x: (rect.left + rect.right) / 2,
        y: (rect.top + rect.bottom) / 2
    };
}
}),
"[project]/node_modules/@base-ui/react/slider/utils/getPushedThumbValues.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getPushedThumbValues",
    ()=>getPushedThumbValues
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$clamp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/clamp.mjs [app-client] (ecmascript)");
;
function getPushedThumbValues({ values, index, nextValue, min, max, step, minStepsBetweenValues, initialValues }) {
    if (values.length === 0) {
        return [];
    }
    const nextValues = values.slice();
    const minValueDifference = step * minStepsBetweenValues;
    const lastIndex = nextValues.length - 1;
    const baseInitialValues = initialValues ?? values;
    const indexMin = min + index * minValueDifference;
    const indexMax = max - (lastIndex - index) * minValueDifference;
    nextValues[index] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$clamp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(nextValue, indexMin, indexMax);
    for(let i = index + 1; i <= lastIndex; i += 1){
        const minAllowed = nextValues[i - 1] + minValueDifference;
        const maxAllowed = max - (lastIndex - i) * minValueDifference;
        const initialValue = baseInitialValues[i] ?? nextValues[i];
        let candidate = Math.max(nextValues[i], minAllowed);
        if (initialValue < candidate) {
            candidate = Math.max(initialValue, minAllowed);
        }
        nextValues[i] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$clamp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(candidate, minAllowed, maxAllowed);
    }
    for(let i = index - 1; i >= 0; i -= 1){
        const maxAllowed = nextValues[i + 1] - minValueDifference;
        const minAllowed = min + i * minValueDifference;
        const initialValue = baseInitialValues[i] ?? nextValues[i];
        let candidate = Math.min(nextValues[i], maxAllowed);
        if (initialValue > candidate) {
            candidate = Math.min(initialValue, maxAllowed);
        }
        nextValues[i] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$clamp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(candidate, minAllowed, maxAllowed);
    }
    for(let i = 0; i <= lastIndex; i += 1){
        nextValues[i] = Number(nextValues[i].toFixed(12));
    }
    return nextValues;
}
}),
"[project]/node_modules/@base-ui/react/slider/utils/getSliderValue.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getSliderValue",
    ()=>getSliderValue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$clamp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/clamp.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$replaceArrayItemAtIndex$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/utils/replaceArrayItemAtIndex.mjs [app-client] (ecmascript)");
;
;
function getSliderValue(valueInput, index, min, max, range, values) {
    let newValue = valueInput;
    newValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$clamp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(newValue, min, max);
    if (range) {
        newValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$replaceArrayItemAtIndex$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceArrayItemAtIndex"])(values, index, // Bound the new value to the thumb's neighbours.
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$clamp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(newValue, values[index - 1] ?? -Infinity, values[index + 1] ?? Infinity));
    }
    return newValue;
}
}),
"[project]/node_modules/@base-ui/react/slider/utils/replaceArrayItemAtIndex.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "replaceArrayItemAtIndex",
    ()=>replaceArrayItemAtIndex
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$asc$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/utils/asc.mjs [app-client] (ecmascript)");
;
function replaceArrayItemAtIndex(array, index, newValue) {
    const output = array.slice();
    output[index] = newValue;
    return output.sort(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$asc$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["asc"]);
}
}),
"[project]/node_modules/@base-ui/react/slider/utils/resolveThumbCollision.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "resolveThumbCollision",
    ()=>resolveThumbCollision
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$clamp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/clamp.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$getPushedThumbValues$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/utils/getPushedThumbValues.mjs [app-client] (ecmascript)");
;
;
function resolveThumbCollision({ behavior, values, currentValues, initialValues, pressedIndex, nextValue, min, max, step, minStepsBetweenValues }) {
    const activeValues = currentValues ?? values;
    const baselineValues = initialValues ?? values;
    const range = activeValues.length > 1;
    if (!range) {
        return {
            value: nextValue,
            thumbIndex: 0,
            didSwap: false
        };
    }
    const minValueDifference = step * minStepsBetweenValues;
    switch(behavior){
        case 'swap':
            {
                const pressedInitialValue = activeValues[pressedIndex];
                const epsilon = 1e-7;
                const candidateValues = activeValues.slice();
                const previousNeighbor = candidateValues[pressedIndex - 1];
                const nextNeighbor = candidateValues[pressedIndex + 1];
                const lowerBound = previousNeighbor != null ? previousNeighbor + minValueDifference : min;
                const upperBound = nextNeighbor != null ? nextNeighbor - minValueDifference : max;
                const constrainedValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$clamp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(nextValue, lowerBound, upperBound);
                const pressedValueAfterClamp = Number(constrainedValue.toFixed(12));
                candidateValues[pressedIndex] = pressedValueAfterClamp;
                const movingForward = nextValue > pressedInitialValue;
                const movingBackward = nextValue < pressedInitialValue;
                const shouldSwapForward = movingForward && nextNeighbor != null && nextValue >= nextNeighbor - epsilon;
                const shouldSwapBackward = movingBackward && previousNeighbor != null && nextValue <= previousNeighbor + epsilon;
                if (!shouldSwapForward && !shouldSwapBackward) {
                    return {
                        value: candidateValues,
                        thumbIndex: pressedIndex,
                        didSwap: false
                    };
                }
                const targetIndex = shouldSwapForward ? pressedIndex + 1 : pressedIndex - 1;
                const initialValuesForPush = candidateValues.map((_, index)=>{
                    if (index === pressedIndex) {
                        return pressedValueAfterClamp;
                    }
                    const baseline = baselineValues[index];
                    if (baseline != null) {
                        return baseline;
                    }
                    return activeValues[index];
                });
                let nextValueForTarget = nextValue;
                if (shouldSwapForward) {
                    nextValueForTarget = Math.max(nextValue, candidateValues[targetIndex]);
                } else {
                    nextValueForTarget = Math.min(nextValue, candidateValues[targetIndex]);
                }
                const adjustedValues = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$getPushedThumbValues$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPushedThumbValues"])({
                    values: candidateValues,
                    index: targetIndex,
                    nextValue: nextValueForTarget,
                    min,
                    max,
                    step,
                    minStepsBetweenValues,
                    initialValues: initialValuesForPush
                });
                const neighborIndex = shouldSwapForward ? targetIndex - 1 : targetIndex + 1;
                if (neighborIndex >= 0 && neighborIndex < adjustedValues.length) {
                    const previousValue = adjustedValues[neighborIndex - 1];
                    const nextValueAfter = adjustedValues[neighborIndex + 1];
                    let neighborLowerBound = previousValue != null ? previousValue + minValueDifference : min;
                    neighborLowerBound = Math.max(neighborLowerBound, min + neighborIndex * minValueDifference);
                    let neighborUpperBound = nextValueAfter != null ? nextValueAfter - minValueDifference : max;
                    neighborUpperBound = Math.min(neighborUpperBound, max - (adjustedValues.length - 1 - neighborIndex) * minValueDifference);
                    const restoredValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$clamp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(pressedValueAfterClamp, neighborLowerBound, neighborUpperBound);
                    adjustedValues[neighborIndex] = Number(restoredValue.toFixed(12));
                }
                return {
                    value: adjustedValues,
                    thumbIndex: targetIndex,
                    didSwap: true
                };
            }
        case 'push':
            {
                const nextValues = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$utils$2f$getPushedThumbValues$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPushedThumbValues"])({
                    values: activeValues,
                    index: pressedIndex,
                    nextValue,
                    min,
                    max,
                    step,
                    minStepsBetweenValues
                });
                return {
                    value: nextValues,
                    thumbIndex: pressedIndex,
                    didSwap: false
                };
            }
        case 'none':
        default:
            {
                const candidateValues = activeValues.slice();
                const previousNeighbor = candidateValues[pressedIndex - 1];
                const nextNeighbor = candidateValues[pressedIndex + 1];
                const lowerBound = previousNeighbor != null ? previousNeighbor + minValueDifference : min;
                const upperBound = nextNeighbor != null ? nextNeighbor - minValueDifference : max;
                const constrainedValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$clamp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(nextValue, lowerBound, upperBound);
                candidateValues[pressedIndex] = Number(constrainedValue.toFixed(12));
                return {
                    value: candidateValues,
                    thumbIndex: pressedIndex,
                    didSwap: false
                };
            }
    }
}
}),
"[project]/node_modules/@base-ui/react/slider/utils/roundValueToStep.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getDecimalPrecision",
    ()=>getDecimalPrecision,
    "roundValueToStep",
    ()=>roundValueToStep
]);
function getDecimalPrecision(num) {
    if (num === 0) {
        return 0;
    }
    // This handles the case when num is very small (0.00000001), js will turn this into 1e-8.
    // When num is bigger than 1 or less than -1 it won't get converted to this notation so it's fine.
    if (Math.abs(num) < 1) {
        const parts = num.toExponential().split('e-');
        const matissaDecimalPart = parts[0].split('.')[1];
        return (matissaDecimalPart ? matissaDecimalPart.length : 0) + parseInt(parts[1], 10);
    }
    const decimalPart = num.toString().split('.')[1];
    return decimalPart ? decimalPart.length : 0;
}
function roundValueToStep(value, step, min) {
    const nearest = Math.round((value - min) / step) * step + min;
    return Number(nearest.toFixed(Math.max(getDecimalPrecision(step), getDecimalPrecision(min))));
}
}),
"[project]/node_modules/@base-ui/react/slider/utils/validateMinimumDistance.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "validateMinimumDistance",
    ()=>validateMinimumDistance
]);
function validateMinimumDistance(values, step, minStepsBetweenValues) {
    if (!Array.isArray(values)) {
        return true;
    }
    const distances = values.reduce((acc, val, index, vals)=>{
        if (index === vals.length - 1) {
            return acc;
        }
        acc.push(Math.abs(val - vals[index + 1]));
        return acc;
    }, []);
    return Math.min(...distances) >= step * minStepsBetweenValues;
}
}),
"[project]/node_modules/@base-ui/react/slider/value/SliderValue.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SliderValue",
    ()=>SliderValue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$formatNumber$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/utils/formatNumber.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$SliderRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/root/SliderRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/slider/root/stateAttributesMapping.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
const SliderValue = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function SliderValue(componentProps, forwardedRef) {
    const { 'aria-live': ariaLive = 'off', render, className, children, style, ...elementProps } = componentProps;
    const { thumbMap, state, values, formatOptionsRef, locale } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$SliderRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSliderRootContext"])();
    let htmlFor = '';
    for (const thumbMetadata of thumbMap.values()){
        if (thumbMetadata?.inputId) {
            htmlFor += `${thumbMetadata.inputId} `;
        }
    }
    const outputFor = htmlFor.trim() === '' ? undefined : htmlFor.trim();
    const formattedValues = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "SliderValue.SliderValue.useMemo[formattedValues]": ()=>{
            const arr = [];
            for(let i = 0; i < values.length; i += 1){
                arr.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$formatNumber$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatNumber"])(values[i], locale, formatOptionsRef.current ?? undefined));
            }
            return arr;
        }
    }["SliderValue.SliderValue.useMemo[formattedValues]"], [
        formatOptionsRef,
        locale,
        values
    ]);
    const defaultDisplayValue = values.map((v, i)=>formattedValues[i] || v).join(' – ');
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('output', componentProps, {
        state,
        ref: forwardedRef,
        props: [
            {
                // off by default because it will keep announcing when the slider is being dragged
                // and also when the value is changing (but not yet committed)
                'aria-live': ariaLive,
                children: typeof children === 'function' ? children(formattedValues, values) : defaultDisplayValue,
                htmlFor: outputFor
            },
            elementProps
        ],
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$slider$2f$root$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sliderStateAttributesMapping"]
    });
    return element;
});
if ("TURBOPACK compile-time truthy", 1) SliderValue.displayName = "SliderValue";
}),
"[project]/node_modules/@base-ui/react/utils/formatNumber.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cache",
    ()=>cache,
    "formatNumber",
    ()=>formatNumber,
    "formatNumberValue",
    ()=>formatNumberValue,
    "getFormatter",
    ()=>getFormatter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$stringifyLocale$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/utils/stringifyLocale.mjs [app-client] (ecmascript)");
;
const cache = new Map();
function getFormatter(locale, options) {
    const optionsString = JSON.stringify({
        locale: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$stringifyLocale$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringifyLocale"])(locale),
        options
    });
    const cachedFormatter = cache.get(optionsString);
    if (cachedFormatter) {
        return cachedFormatter;
    }
    const formatter = new Intl.NumberFormat(locale, options);
    cache.set(optionsString, formatter);
    return formatter;
}
function formatNumber(value, locale, options) {
    if (value == null) {
        return '';
    }
    return getFormatter(locale, options).format(value);
}
function formatNumberValue(value, locale, format) {
    if (value == null) {
        return '';
    }
    if (!format) {
        return formatNumber(value / 100, locale, {
            style: 'percent'
        });
    }
    return formatNumber(value, locale, format);
}
}),
"[project]/node_modules/@base-ui/react/utils/stringifyLocale.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "stringifyLocale",
    ()=>stringifyLocale
]);
function stringifyLocale(locale) {
    if (Array.isArray(locale)) {
        return locale.map((value)=>stringifyLocale(value)).join(',');
    }
    if (locale == null) {
        return '';
    }
    return String(locale);
}
}),
"[project]/node_modules/@base-ui/react/utils/useIsHydrating.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useIsHydrating",
    ()=>useIsHydrating
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$sync$2d$external$2d$store$2f$shim$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/use-sync-external-store/shim/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/empty.mjs [app-client] (ecmascript)");
;
;
function subscribe() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOOP"];
}
function getSnapshot() {
    return false;
}
function getServerSnapshot() {
    return true;
}
function useIsHydrating() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$sync$2d$external$2d$store$2f$shim$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(subscribe, getSnapshot, getServerSnapshot);
}
}),
"[project]/node_modules/@base-ui/react/utils/valueToPercent.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "valueToPercent",
    ()=>valueToPercent
]);
function valueToPercent(value, min, max) {
    return (value - min) * 100 / (max - min);
}
}),
]);

//# sourceMappingURL=node_modules_%40base-ui_react_14fn5ph._.js.map